<?php

namespace threewp_broadcast\collections;

class strings_with_metadata
	extends \threewp_broadcast\collections\strings
{
	use \threewp_broadcast\collections\traits\metadata;
}

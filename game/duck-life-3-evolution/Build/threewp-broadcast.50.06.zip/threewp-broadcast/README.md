threewp_broadcast
=================

Network Content Syndication Made Easy! Automatically share content by multiposting between multisite blogs.

The plugin is available at the [Wordpress plugin repo](https://wordpress.org/plugins/threewp-broadcast/), and on its own page at [broadcast.plainviewplugins.com](https://broadcast.plainviewplugins.com/).
